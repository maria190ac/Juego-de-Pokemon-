// script.js
// Aquí va el JavaScript completo del juego (sincronización, rondas, lógica, etc.)